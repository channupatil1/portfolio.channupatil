
Photo & Video Editing Portfolio — Patil Prints
---------------------------------------------
Files:
  - index.html
  - styles.css
  - script.js
  - assets/* (sample placeholder images)

How to use:
  1. Unzip the package.
  2. Open index.html in a browser to preview the portfolio locally.
  3. Replace images in assets/ with your actual photos and update video embed links.
  4. For production, host on GitHub Pages, Netlify, or your preferred host.
